{
  "schema": 1,
  "algorithm": "Ed25519",
  "signature": "73C5ZiAoejwfO/NOdbduVIgfp+TxwknmfNx9Oz2iOjp0LFVo0EWnIWB5eZsGDZSbdXiETVoZkTlLPASp7QdLAQ=="
}
