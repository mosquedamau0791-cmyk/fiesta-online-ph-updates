{
  "schema": 1,
  "algorithm": "Ed25519",
  "signature": "L+DSatA8WWnOOJ9twGvppQkjLoQB++CMSetEYCuP5F5HnmIEYVS5Q2zOtxuxpuxSgRehaVKFcmZ/mz7LJjETCQ=="
}
